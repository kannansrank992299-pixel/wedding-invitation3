# Wedding Invitation - Flask

## Run locally
```bash
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000

## Deploy to Vercel
Upload this entire folder to GitHub, then import the repository into Vercel.

Vercel will use `api/index.py` and `vercel.json` to run the Flask app.
